from app.main import app
from app.schemas.common import SignalFeatures, SignalGenerationParams
from app.services.anomaly_scorer import anomaly_scorer
from app.services.modulation_classifier import modulation_classifier
from app.services.signal_generator import signal_generator

def test_health_endpoint_is_registered():
    """The deployment readiness endpoint must be available without API versioning."""
    assert any(route.path == "/health" for route in app.routes)


def test_iq_generator_returns_matched_iq_samples():
    result = signal_generator.generate_iq_samples(
        SignalGenerationParams(
            modulation_type="QPSK",
            sample_rate=1_000,
            center_frequency=100,
            duration=0.01,
            snr_db=20,
        )
    )
    assert len(result.i_samples) == len(result.q_samples) == 10
    assert result.modulation_type == "QPSK"


def test_classifier_and_anomaly_score_return_safe_values():
    features = SignalFeatures(
        fft_peaks=[1.0, 0.3, 0.1],
        spectral_centroid=2_400_000,
        bandwidth=200_000,
        snr_estimate=18,
        higher_order_stats=[0.1, 0.2, 0.3],
        cyclic_features=[0.4, 0.5, 0.6],
    )
    modulation, confidence = modulation_classifier.classify(features)
    assert modulation == "16QAM"
    assert 0.0 <= confidence <= 1.0
    assert 0.0 <= anomaly_scorer.score(features) <= 1.0
