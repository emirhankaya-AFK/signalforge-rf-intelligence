from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app import crud, models, schemas
from app.api import deps

router = APIRouter()


@router.get("/", response_model=List[schemas.Capture])
def read_captures(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    device_id: Optional[str] = None,
):
    """
    Retrieve captures.
    """
    captures = crud.capture.get_multi(db, skip=skip, limit=limit, device_id=device_id)
    return captures


@router.post("/", response_model=schemas.Capture)
def create_capture(
    *,
    db: Session = Depends(deps.get_db),
    capture_in: schemas.CaptureCreate,
):
    """
    Create new capture.
    """
    capture = crud.capture.create(db=db, obj_in=capture_in)
    return capture


@router.get("/{capture_id}", response_model=schemas.Capture)
def read_capture(
    *,
    db: Session = Depends(deps.get_db),
    capture_id: int,
):
    """
    Get capture by ID.
    """
    capture = crud.capture.get(db=db, id=capture_id)
    if not capture:
        raise HTTPException(status_code=404, detail="Capture not found")
    return capture


@router.delete("/{capture_id}", response_model=schemas.Capture)
def delete_capture(
    *,
    db: Session = Depends(deps.get_db),
    capture_id: int,
):
    """
    Delete a capture.
    """
    capture = crud.capture.get(db=db, id=capture_id)
    if not capture:
        raise HTTPException(status_code=404, detail="Capture not found")
    capture = crud.capture.remove(db=db, id=capture_id)
    return capture