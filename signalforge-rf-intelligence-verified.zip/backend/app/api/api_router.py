from fastapi import APIRouter
from app.api import captures, spectrum, signals, alerts, classifier, simulator

api_router = APIRouter()
api_router.include_router(captures.router, prefix="/captures", tags=["captures"])
api_router.include_router(spectrum.router, prefix="/spectrum", tags=["spectrum"])
api_router.include_router(signals.router, prefix="/signals", tags=["signals"])
api_router.include_router(alerts.router, prefix="/alerts", tags=["alerts"])
api_router.include_router(classifier.router, prefix="/classifier", tags=["classifier"])
api_router.include_router(simulator.router, prefix="/simulator", tags=["simulator"])