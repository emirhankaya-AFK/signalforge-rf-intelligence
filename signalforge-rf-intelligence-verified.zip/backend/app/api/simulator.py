from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import crud, models, schemas
from app.api import deps
from app.services.signal_generator import signal_generator

router = APIRouter()


@router.post("/generate", response_model=schemas.IQSampleSet)
def generate_iq_samples(
    *,
    db: Session = Depends(deps.get_db),
    params: schemas.SignalGenerationParams,
):
    """
    Generate synthetic IQ samples with given modulation and interference.
    """
    iq_samples = signal_generator.generate_iq_samples(params)
    return iq_samples
