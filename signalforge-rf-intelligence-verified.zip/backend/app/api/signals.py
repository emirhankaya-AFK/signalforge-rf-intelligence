from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import crud, models, schemas
from app.api import deps

router = APIRouter()


@router.get("/", response_model=List[schemas.Signal])
def read_signals(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    capture_id: int = None,
):
    """
    Retrieve detected signals.
    """
    signals = crud.signal.get_multi(db, skip=skip, limit=limit, capture_id=capture_id)
    return signals


@router.post("/", response_model=schemas.Signal)
def create_signal(
    *,
    db: Session = Depends(deps.get_db),
    signal_in: schemas.SignalCreate,
):
    """
    Create new detected signal.
    """
    signal = crud.signal.create(db=db, obj_in=signal_in)
    return signal