from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import crud, models, schemas
from app.api import deps
from app.services.anomaly_scorer import anomaly_scorer
from app.services.modulation_classifier import modulation_classifier

router = APIRouter()


@router.post("/classify", response_model=schemas.SignalClassification)
def classify_signal(
    *,
    db: Session = Depends(deps.get_db),
    features: schemas.SignalFeatures,
):
    """
    Classify a signal based on its features.
    """
    # Use the modulation classifier service
    modulation, confidence = modulation_classifier.classify(features)
    anomaly_score = anomaly_scorer.score(features)
    return {
        "modulation": modulation,
        "confidence": confidence,
        "anomaly_score": anomaly_score,
    }
