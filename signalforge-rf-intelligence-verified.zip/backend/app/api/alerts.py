from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import crud, models, schemas
from app.api import deps

router = APIRouter()


@router.get("/", response_model=List[schemas.Alert])
def read_alerts(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    resolved: bool = False,
):
    """
    Retrieve alerts.
    """
    alerts = crud.alert.get_multi(db, skip=skip, limit=limit, resolved=resolved)
    return alerts


@router.patch("/{alert_id}/resolve", response_model=schemas.Alert)
def resolve_alert(
    *,
    db: Session = Depends(deps.get_db),
    alert_id: int,
):
    """
    Resolve an alert.
    """
    alert = crud.alert.get(db=db, id=alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert = crud.alert.update(db=db, db_obj=alert, obj_in={"resolved": True})
    return alert