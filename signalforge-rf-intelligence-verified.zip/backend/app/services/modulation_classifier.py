"""Deterministic demo modulation classifier.

The project deliberately keeps this dependency-free at runtime: a production
classifier can replace this class after it is trained and versioned.
"""

from app.schemas.common import SignalFeatures


class ModulationClassifier:
    def classify(self, features: SignalFeatures) -> tuple[str, float]:
        bandwidth = max(features.bandwidth, 0.0)
        peaks = len(features.fft_peaks)
        cyclic_energy = sum(abs(value) for value in features.cyclic_features)

        if bandwidth >= 150_000:
            modulation = "16QAM"
        elif cyclic_energy >= 1.0:
            modulation = "QPSK"
        elif peaks <= 2:
            modulation = "BPSK"
        else:
            modulation = "FM"

        confidence = min(0.95, max(0.50, 0.55 + features.snr_estimate / 80))
        return modulation, round(confidence, 4)


modulation_classifier = ModulationClassifier()
