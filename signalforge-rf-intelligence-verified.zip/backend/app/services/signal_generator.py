import numpy as np
from typing import List, Dict, Any
from app.schemas.common import SignalGenerationParams, IQSampleSet


class SignalGenerator:
    def __init__(self):
        pass

    def generate_iq_samples(self, params: SignalGenerationParams) -> IQSampleSet:
        """
        Generate synthetic IQ samples for the given modulation type and parameters.
        """
        num_samples = int(params.sample_rate * params.duration)
        t = np.linspace(0, params.duration, num_samples, False)
        
        # Center frequency offset
        freq_offset = params.center_frequency
        
        # Baseband signal
        if params.modulation_type == "BPSK":
            # Generate random binary data
            bits = np.random.randint(0, 2, num_samples//10)  # 10 samples per bit
            # Repeat each bit for 10 samples
            baseband = np.repeat(bits * 2 - 1, 10).astype(complex)  # Map 0->-1, 1->1
            # Truncate or pad to num_samples
            if len(baseband) > num_samples:
                baseband = baseband[:num_samples]
            else:
                baseband = np.pad(baseband, (0, num_samples - len(baseband)), 'constant')
            baseband = baseband.astype(complex)
        elif params.modulation_type == "QPSK":
            # Generate random symbols (0-3)
            symbols = np.random.randint(0, 4, num_samples//20)  # 20 samples per symbol
            # Map to complex: 0->1+1j, 1->-1+1j, 2->-1-1j, 3->1-1j
            symbol_map = {
                0: 1+1j,
                1: -1+1j,
                2: -1-1j,
                3: 1-1j
            }
            baseband = np.array([symbol_map[s] for s in symbols])
            # Repeat each symbol for 20 samples
            baseband = np.repeat(baseband, 20)
            # Truncate or pad
            if len(baseband) > num_samples:
                baseband = baseband[:num_samples]
            else:
                baseband = np.pad(baseband, (0, num_samples - len(baseband)), 'constant')
            baseband = baseband.astype(complex)
        elif params.modulation_type == "16QAM":
            # Placeholder: generate random QAM-like signal
            baseband = (np.random.randn(num_samples) + 1j*np.random.randn(num_samples)) / np.sqrt(2)
        else:  # Default to FM-like or noise
            baseband = np.random.randn(num_samples) + 1j*np.random.randn(num_samples)
        
        # Add noise
        noise_power = 10**(-params.snr_db/10)
        noise = np.sqrt(noise_power/2) * (np.random.randn(num_samples) + 1j*np.random.randn(num_samples))
        baseband += noise
        
        # Add interference if specified
        if params.interference:
            for interference in params.interference:
                # Each interference is a dict with type, frequency, power, etc.
                # For simplicity, we'll just add a sinusoidal interference
                freq = interference.get("frequency", 0.0)  # Hz offset from center
                power = interference.get("power", 0.0)  # dB
                # Convert power to amplitude
                amp = 10**(power/20)
                t_local = np.linspace(0, params.duration, num_samples, False)
                interference_signal = amp * np.exp(2j*np.pi*freq*t_local)
                baseband += interference_signal
        
        # Upconvert to center frequency
        carrier = np.exp(2j*np.pi*freq_offset*t)
        rf_signal = baseband * carrier
        
        # Extract I and Q
        i_samples = np.real(rf_signal)
        q_samples = np.imag(rf_signal)
        
        return IQSampleSet(
            i_samples=i_samples.tolist(),
            q_samples=q_samples.tolist(),
            sample_rate=params.sample_rate,
            center_frequency=params.center_frequency,
            modulation_type=params.modulation_type
        )


# Singleton instance
signal_generator = SignalGenerator()
