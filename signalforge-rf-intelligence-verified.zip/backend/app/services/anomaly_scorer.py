"""Interpretable baseline anomaly score for the SignalForge demo."""

from app.schemas.common import SignalFeatures


class AnomalyScorer:
    def score(self, features: SignalFeatures) -> float:
        low_snr_risk = max(0.0, min(1.0, (10 - features.snr_estimate) / 30))
        peak_risk = min(1.0, len(features.fft_peaks) / 20)
        statistic_risk = min(1.0, sum(abs(value) for value in features.higher_order_stats) / 30)
        return round(min(1.0, 0.55 * low_snr_risk + 0.25 * peak_risk + 0.20 * statistic_risk), 4)


anomaly_scorer = AnomalyScorer()
