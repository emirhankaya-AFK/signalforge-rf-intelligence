from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import Base


class Capture(Base):
    __tablename__ = "captures"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String, index=True)
    start_time = Column(DateTime(timezone=True), server_default=func.now())
    end_time = Column(DateTime(timezone=True), nullable=True)
    center_frequency = Column(Float)  # Hz
    sample_rate = Column(Float)  # Hz
    duration = Column(Float)  # seconds
    file_path = Column(String, nullable=True)  # path to stored IQ data
    is_processed = Column(Boolean, default=False)
    signals = relationship("Signal", back_populates="capture")