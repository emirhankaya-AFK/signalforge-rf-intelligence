from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import Base


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    signal_id = Column(Integer, ForeignKey("signals.id"))
    triggered_at = Column(DateTime(timezone=True), server_default=func.now())
    alert_type = Column(String)  # e.g., "modulation_anomaly", "power_surge"
    description = Column(Text)
    severity = Column(String)  # e.g., "low", "medium", "high"
    resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime(timezone=True), nullable=True)

    # Relationship
    signal = relationship("Signal")
