from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import Base


class Signal(Base):
    __tablename__ = "signals"

    id = Column(Integer, primary_key=True, index=True)
    capture_id = Column(Integer, ForeignKey("captures.id"))
    device_id = Column(String, index=True)
    detected_at = Column(DateTime(timezone=True), server_default=func.now())
    frequency = Column(Float)  # Hz
    bandwidth = Column(Float)  # Hz
    power = Column(Float)  # dBm
    snr = Column(Float)  # dB
    modulation_type = Column(String, nullable=True)  # e.g., BPSK, QPSK
    classification_confidence = Column(Float, nullable=True)
    anomaly_score = Column(Float, nullable=True)

    capture = relationship("Capture", back_populates="signals")