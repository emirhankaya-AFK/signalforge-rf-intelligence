from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import settings

# SQLALCHEMY_DATABASE_URL = settings.SQLITE_DATABASE_URL
SQLALCHEMY_DATABASE_URL = "sqlite:///./signalforge.db"
# SQLALCHEMY_DATABASE_URL = settings.SQLITE_DATABASE_URL

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
