from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import websocket
from app.api.api_router import api_router
from app.core.config import settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)


@app.get("/health", tags=["health"])
def health_check() -> dict[str, str]:
    """Lightweight readiness endpoint for containers and load balancers."""
    return {"status": "ok", "service": "signalforge"}

# Set all CORS enabled origins
if settings.BACKEND_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[str(origin) for origin in settings.BACKEND_CORS_ORIGINS],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(api_router, prefix=settings.API_V1_STR)
app.include_router(websocket.router)
