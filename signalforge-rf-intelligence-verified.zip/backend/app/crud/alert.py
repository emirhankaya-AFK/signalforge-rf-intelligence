from typing import List, Optional

from sqlalchemy.orm import Session

from app.crud.base import CRUDBase
from app.models.alert import Alert
from app.schemas.alert import AlertCreate, AlertUpdate


class CRUDAlert(CRUDBase[Alert, AlertCreate, AlertUpdate]):
    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100, resolved: Optional[bool] = None
    ) -> List[Alert]:
        query = db.query(self.model)
        if resolved is not None:
            query = query.filter(Alert.resolved == resolved)
        return query.offset(skip).limit(limit).all()

    def get_multi_by_unresolved(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[Alert]:
        return (
            db.query(self.model)
            .filter(Alert.resolved == False)
            .offset(skip)
            .limit(limit)
            .all()
        )


alert = CRUDAlert(Alert)
