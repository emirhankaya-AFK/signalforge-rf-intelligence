from typing import List, Optional

from sqlalchemy.orm import Session

from app.crud.base import CRUDBase
from app.models.capture import Capture
from app.schemas.capture import CaptureCreate, CaptureUpdate


class CRUDCapture(CRUDBase[Capture, CaptureCreate, CaptureUpdate]):
    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100, device_id: Optional[str] = None
    ) -> List[Capture]:
        query = db.query(self.model)
        if device_id:
            query = query.filter(Capture.device_id == device_id)
        return query.offset(skip).limit(limit).all()

    def get_multi_by_device(
        self, db: Session, *, device_id: str, skip: int = 0, limit: int = 100
    ) -> List[Capture]:
        return (
            db.query(self.model)
            .filter(Capture.device_id == device_id)
            .offset(skip)
            .limit(limit)
            .all()
        )


capture = CRUDCapture(Capture)
