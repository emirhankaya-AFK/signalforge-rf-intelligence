from typing import List, Optional

from sqlalchemy.orm import Session

from app.crud.base import CRUDBase
from app.models.signal import Signal
from app.schemas.signal import SignalCreate, SignalUpdate


class CRUDSignal(CRUDBase[Signal, SignalCreate, SignalUpdate]):
    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100, capture_id: Optional[int] = None
    ) -> List[Signal]:
        query = db.query(self.model)
        if capture_id is not None:
            query = query.filter(Signal.capture_id == capture_id)
        return query.offset(skip).limit(limit).all()

    def get_multi_by_capture(
        self, db: Session, *, capture_id: int, skip: int = 0, limit: int = 100
    ) -> List[Signal]:
        return (
            db.query(self.model)
            .filter(Signal.capture_id == capture_id)
            .offset(skip)
            .limit(limit)
            .all()
        )


signal = CRUDSignal(Signal)
