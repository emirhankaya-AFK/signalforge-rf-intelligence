from app.schemas.alert import Alert, AlertCreate, AlertUpdate
from app.schemas.capture import Capture, CaptureCreate, CaptureUpdate
from app.schemas.common import IQSampleSet, SignalFeatures, SignalGenerationParams, SpectrumSummary
from app.schemas.signal import Signal, SignalCreate, SignalUpdate

from pydantic import BaseModel


class SignalClassification(BaseModel):
    modulation: str
    confidence: float
    anomaly_score: float
