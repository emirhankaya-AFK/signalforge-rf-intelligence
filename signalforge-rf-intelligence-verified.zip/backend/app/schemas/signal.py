from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class SignalBase(BaseModel):
    capture_id: int
    device_id: str
    frequency: float  # Hz
    bandwidth: float  # Hz
    power: float  # dBm
    snr: float  # dB
    modulation_type: Optional[str] = None
    classification_confidence: Optional[float] = None
    anomaly_score: Optional[float] = None


class SignalCreate(SignalBase):
    pass


class SignalUpdate(BaseModel):
    capture_id: Optional[int] = None
    device_id: Optional[str] = None
    frequency: Optional[float] = None
    bandwidth: Optional[float] = None
    power: Optional[float] = None
    snr: Optional[float] = None
    modulation_type: Optional[str] = None
    classification_confidence: Optional[float] = None
    anomaly_score: Optional[float] = None


class SignalInDBBase(SignalBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    detected_at: datetime

class Signal(SignalInDBBase):
    pass


class SignalInDB(SignalInDBBase):
    pass
