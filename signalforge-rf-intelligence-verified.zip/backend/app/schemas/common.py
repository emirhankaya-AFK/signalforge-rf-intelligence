from typing import List, Optional

from pydantic import BaseModel


class SpectrumSummary(BaseModel):
    device_id: str
    start_time: str
    end_time: str
    center_frequency: float
    sample_rate: float
    psd: List[float]  # Power spectral density values
    spectral_centroid: float
    bandwidth: float
    snr_estimate: float


class SignalFeatures(BaseModel):
    fft_peaks: List[float]
    spectral_centroid: float
    bandwidth: float
    snr_estimate: float
    higher_order_stats: List[float]  # e.g., skewness, kurtosis
    cyclic_features: List[float]  # cyclic cumulants, etc.


class SignalGenerationParams(BaseModel):
    modulation_type: str  # BPSK, QPSK, 16QAM, FM
    sample_rate: float
    center_frequency: float
    duration: float
    snr_db: float
    interference: Optional[List[dict]] = None  # list of interference signals
    noise_level: float = 0.0


class IQSampleSet(BaseModel):
    i_samples: List[float]
    q_samples: List[float]
    sample_rate: float
    center_frequency: float
    modulation_type: str