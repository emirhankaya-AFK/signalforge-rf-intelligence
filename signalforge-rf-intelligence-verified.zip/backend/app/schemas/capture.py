from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, ConfigDict


class CaptureBase(BaseModel):
    device_id: str
    center_frequency: float
    sample_rate: float
    duration: float
    file_path: Optional[str] = None


class CaptureCreate(CaptureBase):
    pass


class CaptureUpdate(BaseModel):
    device_id: Optional[str] = None
    center_frequency: Optional[float] = None
    sample_rate: Optional[float] = None
    duration: Optional[float] = None
    end_time: Optional[datetime] = None
    file_path: Optional[str] = None
    is_processed: Optional[bool] = None


class CaptureInDBBase(CaptureBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    start_time: datetime
    end_time: Optional[datetime]
    is_processed: bool

class Capture(CaptureInDBBase):
    pass


class CaptureInDB(CaptureInDBBase):
    pass
