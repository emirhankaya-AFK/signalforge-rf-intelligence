from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class AlertBase(BaseModel):
    signal_id: int
    alert_type: str
    description: str
    severity: str
    resolved: bool = False


class AlertCreate(AlertBase):
    pass


class AlertUpdate(BaseModel):
    signal_id: Optional[int] = None
    alert_type: Optional[str] = None
    description: Optional[str] = None
    severity: Optional[str] = None
    resolved: Optional[bool] = None
    resolved_at: Optional[datetime] = None


class AlertInDBBase(AlertBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    triggered_at: datetime
    resolved_at: Optional[datetime]

class Alert(AlertInDBBase):
    pass


class AlertInDB(AlertInDBBase):
    pass
