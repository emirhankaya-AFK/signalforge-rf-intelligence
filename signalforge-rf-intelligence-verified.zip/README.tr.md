# SignalForge

Elektrik mühendisliği uygulamaları için RF spektrumu zekası ve sinyal anomali platformu.

## Genel Bakış
SignalForge, RF spektrumu zekası ve sinyal anomali tespiti için sıhhiye platformudur. Özellikleri şunlardır:
- RF cihaz modelleri, captura yönetimi ve spektrüm analizi ile FastAPI backend'i
- Koyu RF-konsolü kullanıcı arayüzü ve görselleştirmelerine sahip React TypeScript Vite frontend'i
- BPSK, QPSK, 16QAM ve FM benzeri modülasyonlar için deterministik sentetik IQ-sinyal üreteci
- FFT PSD, spektral centroid, bant genişliği ve SNR tahmini gibi DSP özellikleri
- CPU-only scikit-learn modülasyon sınıflandırıcı ve anomali skorlama
- REST endpoint'leri ve WebSocket spektrüm beslemesi
- Docker Compose, Kubernetes manifestleri ve CI/CD hatlar

## Mimari
Detaylı mimari için [docs/architecture.md](docs/architecture.md) dosyasına bakın.

## API Referansı
API dokümantasyonu için [docs/api.md](docs/api.md) dosyasına bakın.

## Tehdit Modeli
Güvenlik konularına ilişkin değerlendirme için [docs/threat-model.md](docs/threat-model.md) dosyasına bakın.

## Başlarken

### Ön Gereksinimler
- Docker ve Docker Compose
- (Opsiyonel) Prodüksiyon dağıtımı için Kubernetes kümesi

### Yerel Geliştirme
1. Depoyu klonlayın
2. `.env.example` dosyasını `.env` olarak kopyalayın ve gerektiğini göre ayarlayın
3. Tüm servisleri başlatmak için `make up` komutunu çalıştırın
4. Backend API http://localhost:8000 adresinde kullanılabilir
5. Frontend UI http://localhost:3000 adresinde kullanılabilir

## Örnek Veri Üretimi
Gösterim amaçlı örnek veri üretmek için:
```bash
docker-compose run --rm backend python /app/scripts/generate_sample_data.py
```

## Lisans
MIT Lisansı - ayrıntılar için [LICENSE](LICENSE) dosyasına bakın.

## Dokümantasyon
- [Mimari](docs/architecture.md)
- [API Referansı](docs/api.md)
- [Tehdit Modeli](docs/threat-model.md)