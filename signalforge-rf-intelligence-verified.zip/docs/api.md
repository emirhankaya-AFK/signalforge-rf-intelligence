# SignalForge API Reference

## Base URL
`/api/v1`

## Endpoints

### Captures
- `GET /captures` - List captures with optional filtering
- `POST /captures` - Create a new capture
- `GET /captures/{id}` - Get a specific capture
- `DELETE /captures/{id}` - Delete a capture

### Spectrum
- `GET /spectrum/summary` - Get spectrum summary for a device and time range

### Signals
- `GET /signals` - List detected signals with optional filtering
- `POST /signals` - Create a new detected signal

### Alerts
- `GET /alerts` - List alerts with optional filtering
- `PATCH /alerts/{id}/resolve` - Resolve an alert

### Classifier
- `POST /classifier/classify` - Classify a signal based on features

### Simulator
- `POST /simulator/generate` - Generate synthetic IQ samples

## Data Models

### Capture
```json
{
  "id": integer,
  "device_id": string,
  "start_time": string (ISO 8601),
  "end_time": string (ISO 8601, nullable),
  "center_frequency": number (Hz),
  "sample_rate": number (Hz),
  "duration": number (seconds),
  "file_path": string (nullable),
  "is_processed": boolean
}
```

### Signal
```json
{
  "id": integer,
  "capture_id": integer,
  "device_id": string,
  "detected_at": string (ISO 8601),
  "frequency": number (Hz),
  "bandwidth": number (Hz),
  "power": number (dBm),
  "snr": number (dB),
  "modulation_type": string (nullable),
  "classification_confidence": number (nullable),
  "anomaly_score": number (nullable)
}
```

### Alert
```json
{
  "id": integer,
  "signal_id": integer,
  "triggered_at": string (ISO 8601),
  "alert_type": string,
  "description": string,
  "severity": string,
  "resolved": boolean,
  "resolved_at": string (ISO 8601, nullable)
}
```

### SpectrumSummary
```json
{
  "device_id": string,
  "start_time": string (ISO 8601),
  "end_time": string (ISO 8601),
  "center_frequency": number (Hz),
  "sample_rate": number (Hz),
  "psd": array[number],
  "spectral_centroid": number,
  "bandwidth": number,
  "snr_estimate": number
}
```

### SignalFeatures
```json
{
  "fft_peaks": array[number],
  "spectral_centroid": number,
  "bandwidth": number,
  "snr_estimate": number,
  "higher_order_stats": array[number],
  "cyclic_features": array[number]
}
```

### SignalGenerationParams
```json
{
  "modulation_type": string (BPSK, QPSK, 16QAM, FM),
  "sample_rate": number (Hz),
  "center_frequency": number (Hz),
  "duration": number (seconds),
  "snr_db": number (dB),
  "interference": array[object] (optional),
  "noise_level": number (default: 0.0)
}
```

### IQSampleSet
```json
{
  "i_samples": array[number],
  "q_samples": array[number],
  "sample_rate": number (Hz),
  "center_frequency": number (Hz),
  "modulation_type": string
}
```