# SignalForge Architecture

## Overview
SignalForge is a RF spectrum intelligence and signal anomaly platform designed for electrical engineering applications. It consists of a FastAPI backend, a React TypeScript Vite frontend, and a synthetic IQ-signal generator.

## Components

### Backend (FastAPI)
- **RF Receiver/Device Model**: Represents SDR devices and their configurations
- **Capture Model**: Stores metadata about IQ data captures
- **Spectrum Snapshot**: Power spectral density and derived features
- **Detected Signal**: Signals identified during processing
- **Alert**: Anomalies or threshold crossings
- **Classifier Model Version**: Tracks versions of modulation classification models
- **Synthetic Modulations**: BPSK, QPSK, 16QAM, FM-like signals with noise/interference
- **DSP Features**: FFT PSD, spectral centroid, bandwidth, SNR estimate
- **CPU-only scikit-learn Modulation Classifier**: RandomForest for modulation classification
- **Anomaly Scoring**: IsolationForest for anomaly detection
- **REST Endpoints**: For captures, spectrum summaries, classification, anomaly alerts, and what-if simulation
- **WebSocket Spectrum Feed**: Real-time spectrum data streaming
- **Typed Validation**: Pydantic models for request/response validation
- **SQLite Demo Mode**: Lightweight database for demonstration

### Frontend (React TypeScript Vite)
- **Dark RF-console UI**: Optimized for radio frequency analysis
- **Waterfall/Spectrum-like Visuals**: Frequency over time and power spectral density
- **Capture List**: Browse and manage IQ captures
- **Classification Confidence Panel**: Real-time modulation classification results
- **Anomaly Alert Workflow**: View, acknowledge, and resolve alerts
- **Simulator Controls**: Adjust parameters for synthetic signal generation
- **Model Metrics**: Display performance metrics of ML models

### Infrastructure
- **Docker Compose**: Local development orchestration
- **Dockerfiles**: Container definitions for backend and frontend
- **Kubernetes Manifests**: Production deployment configurations
- **CI/CD**: GitHub Actions for testing and linting