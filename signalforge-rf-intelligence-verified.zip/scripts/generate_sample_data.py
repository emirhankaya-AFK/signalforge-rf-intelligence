"""
Sample data generator for SignalForge.
Generates synthetic captures and signals for demonstration.
"""
import sqlite3
import numpy as np
from datetime import datetime, timedelta
from app.db.session import SessionLocal
from app import crud, models, schemas

def init_db():
    """Initialize database with sample data."""
    db = SessionLocal()
    # Create tables
    models.Base.metadata.create_all(bind=db.get_bind())
    
    # Check if we already have data
    if db.query(models.Capture).count() > 0:
        print("Database already contains data. Skipping generation.")
        return
    
    # Generate sample captures
    captures_data = [
        {
            "device_id": "USRP-001",
            "center_frequency": 2.4e9,
            "sample_rate": 2e6,
            "duration": 5.0,
            "file_path": "/data/capture_001.iq",
            "is_processed": True
        },
        {
            "device_id": "USRP-002",
            "center_frequency": 5.8e9,
            "sample_rate": 10e6,
            "duration": 3.0,
            "file_path": "/data/capture_002.iq",
            "is_processed": False
        },
        {
            "device_id": "RTL-SDR-001",
            "center_frequency": 433e6,
            "sample_rate": 1e6,
            "duration": 10.0,
            "file_path": "/data/capture_003.iq",
            "is_processed": True
        }
    ]
    
    captures = []
    for capture_data in captures_data:
        capture_in = schemas.CaptureCreate(**capture_data)
        capture = crud.capture.create(db, obj_in=capture_in)
        captures.append(capture)
        print(f"Created capture: {capture.id}")
    
    # Generate sample signals for each capture
    for capture in captures:
        # Generate 2-5 signals per capture
        num_signals = np.random.randint(2, 6)
        for i in range(num_signals):
            signal_in = schemas.SignalCreate(
                capture_id=capture.id,
                device_id=capture.device_id,
                frequency=capture.center_frequency + np.random.uniform(-0.5e6, 0.5e6),
                bandwidth=np.random.uniform(0.1e6, 2e6),
                power=np.random.uniform(-100, -50),
                snr=np.random.uniform(5, 30),
                modulation_type=np.random.choice(["BPSK", "QPSK", "16QAM", "FM"]),
                classification_confidence=np.random.uniform(0.7, 0.99),
                anomaly_score=np.random.uniform(0.0, 0.3)  # low anomaly for normal signals
            )
            signal = crud.signal.create(db, obj_in=signal_in)
            print(f"  Created signal: {signal.id} for capture {capture.id}")
            
            # Occasionally create an alert for high anomaly score
            if np.random.random() < 0.1:  # 10% chance
                alert_in = schemas.AlertCreate(
                    signal_id=signal.id,
                    alert_type="modulation_anomaly",
                    description=f"Anomalous {signal.modulation_type} signal detected",
                    severity=np.random.choice(["low", "medium", "high"]),
                    resolved=False
                )
                alert = crud.alert.create(db, obj_in=alert_in)
                print(f"    Created alert: {alert.id}")
    
    db.close()
    print("Sample data generation complete.")

if __name__ == "__main__":
    init_db()