# Shared

This directory is intended for shared code between backend and frontend,
such as TypeScript interfaces or utility functions that are used in both.

Currently empty as the backend is Python and frontend is TypeScript.