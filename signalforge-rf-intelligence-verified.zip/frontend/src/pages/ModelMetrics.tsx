import React from 'react'

const ModelMetrics: React.FC = () => {
  return (
    <div className="model-metrics">
      <h2>Model Metrics</h2>
      <div className="metrics-grid">
        <div className="metric-card">
          <h3>Modulation Classifier</h3>
          <p>Accuracy: 92.5%</p>
          <p>Precision: 0.91</p>
          <p>Recall: 0.93</p>
        </div>
        <div className="metric-card">
          <h3>Anomaly Scorer</h3>
          <p>ROC AUC: 0.89</p>
          <p>False Positive Rate: 0.05</p>
        </div>
      </div>
    </div>
  )
}

export default ModelMetrics