import React, { useState } from 'react'
import { SignalGeneratorControls } from '../components/SignalGeneratorControls'
import { IQVisualizer } from '../components/IQVisualizer'

const Simulator: React.FC = () => {
  const [params, setParams] = useState({
    modulationType: 'BPSK',
    sampleRate: 2e6,
    centerFrequency: 2.4e9,
    duration: 0.001, // 1 ms
    snrDb: 10,
  })

  return (
    <div className="simulator">
      <h2>Signal Simulator</h2>
      <SignalGeneratorControls params={params} setParams={setParams} />
      <IQVisualizer params={params} />
    </div>
  )
}

export default Simulator