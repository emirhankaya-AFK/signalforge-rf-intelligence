import React from 'react'
import { WaterfallChart } from '../components/WaterfallChart'
import { SpectrumChart } from '../components/SpectrumChart'
import { ClassificationPanel } from '../components/ClassificationPanel'
import { AlertList } from '../components/AlertList'

const Dashboard: React.FC = () => {
  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <div className="dashboard-grid">
        <div className="dashboard-item">
          <WaterfallChart />
        </div>
        <div className="dashboard-item">
          <SpectrumChart />
        </div>
        <div className="dashboard-item">
          <ClassificationPanel />
        </div>
        <div className="dashboard-item">
          <AlertList />
        </div>
      </div>
    </div>
  )
}

export default Dashboard