import React from 'react'

const CaptureList: React.FC = () => {
  return (
    <div className="capture-list">
      <h2>Capture List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Device ID</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Center Frequency (Hz)</th>
            <th>Sample Rate (Hz)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {/* Placeholder rows */}
          <tr>
            <td>1</td>
            <td>USRP-001</td>
            <td>2026-10-08 10:00:00</td>
            <td>2026-10-08 10:05:00</td>
            <td>2.4e9</td>
            <td>2e6</td>
            <td>
              <button>View</button>
              <button>Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

export default CaptureList