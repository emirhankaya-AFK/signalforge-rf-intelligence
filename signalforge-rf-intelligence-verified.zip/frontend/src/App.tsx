import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import CaptureList from './pages/CaptureList'
import Simulator from './pages/Simulator'
import ModelMetrics from './pages/ModelMetrics'

function App() {
  return (
    <Router>
      <div className="App">
        <header className="app-header">
          <h1>SignalForge</h1>
          <nav>
            <ul>
              <li><a href="/">Dashboard</a></li>
              <li><a href="/captures">Captures</a></li>
              <li><a href="/simulator">Simulator</a></li>
              <li><a href="/metrics">Model Metrics</a></li>
            </ul>
          </nav>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/captures" element={<CaptureList />} />
            <Route path="/simulator" element={<Simulator />} />
            <Route path="/metrics" element={<ModelMetrics />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App