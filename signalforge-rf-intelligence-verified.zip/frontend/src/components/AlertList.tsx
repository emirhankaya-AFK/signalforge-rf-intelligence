import React from 'react'

const AlertList: React.FC = () => {
  const alerts = [
    { id: 1, type: 'Modulation Anomaly', severity: 'high', time: '2026-10-08 10:02:15' },
    { id: 2, type: 'Power Surge', severity: 'medium', time: '2026-10-08 10:03:30' },
  ]

  return (
    <div className="alert-list">
      <h3>Recent Alerts</h3>
      <ul>
        {alerts.map(alert => (
          <li key={alert.id} className={`alert alert-${alert.severity.toLowerCase()}`}>
            <strong>{alert.type}</strong> ({alert.severity}) - {alert.time}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default AlertList