import React from 'react'

const ClassificationPanel: React.FC = () => {
  return (
    <div className="classification-panel">
      <h3>Classification Confidence</h3>
      <div className="confidence-meter">
        <div className="label">BPSK</div>
        <div className="bar">
          <div className="fill" style={{ width: '75%' }}></div>
        </div>
        <div className="value">75%</div>
      </div>
      <div className="confidence-meter">
        <div className="label">QPSK</div>
        <div className="bar">
          <div className="fill" style={{ width: '10%' }}></div>
        </div>
        <div className="value">10%</div>
      </div>
      <div className="confidence-meter">
        <div className="label">16QAM</div>
        <div className="bar">
          <div className="fill" style={{ width: '15%' }}></div>
        </div>
        <div className="value">15%</div>
      </div>
    </div>
  )
}

export default ClassificationPanel