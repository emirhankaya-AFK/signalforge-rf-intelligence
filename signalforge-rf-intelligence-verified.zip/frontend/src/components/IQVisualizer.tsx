import React from 'react'

type IQVisualizerProps = {
  params: {
    modulationType: string
    sampleRate: number
    centerFrequency: number
    duration: number
    snrDb: number
  }
}

const IQVisualizer: React.FC<IQVisualizerProps> = ({ params }) => {
  return (
    <div className="iq-visualizer">
      <h3>IQ Signal Visualization</h3>
      <div className="chart-placeholder">
        <div className="placeholder">I/Q Constellation or Time Domain</div>
      </div>
      <div className="params-summary">
        <p>Modulation: {params.modulationType}</p>
        <p>Sample Rate: {params.sampleRate} Hz</p>
        <p>Center Frequency: {params.centerFrequency} Hz</p>
        <p>Duration: {params.duration} s</p>
        <p>SNR: {params.snrDb} dB</p>
      </div>
    </div>
  )
}

export default IQVisualizer