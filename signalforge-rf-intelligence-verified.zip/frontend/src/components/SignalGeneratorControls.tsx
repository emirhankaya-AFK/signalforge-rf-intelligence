import React from 'react'

type SignalGeneratorControlsProps = {
  params: {
    modulationType: string
    sampleRate: number
    centerFrequency: number
    duration: number
    snrDb: number
  }
  setParams: React.Dispatch<React.SetStateAction<{
    modulationType: string
    sampleRate: number
    centerFrequency: number
    duration: number
    snrDb: number
  }>>
}

const SignalGeneratorControls: React.FC<SignalGeneratorControlsProps> = ({ params, setParams }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setParams(prev => ({
      ...prev,
      [name]: name === 'sampleRate' || name === 'centerFrequency' || name === 'duration' || name === 'snrDb'
        ? parseFloat(value)
        : value
    }))
  }

  return (
    <div className="signal-generator-controls">
      <h3>Simulation Parameters</h3>
      <label>
        Modulation Type:
        <select name="modulationType" value={params.modulationType} onChange={handleChange}>
          <option value="BPSK">BPSK</option>
          <option value="QPSK">QPSK</option>
          <option value="16QAM">16QAM</option>
          <option value="FM">FM</option>
        </select>
      </label>
      <label>
        Sample Rate (Hz):
        <input
          type="number"
          name="sampleRate"
          value={params.sampleRate}
          onChange={handleChange}
          step="any"
        />
      </label>
      <label>
        Center Frequency (Hz):
        <input
          type="number"
          name="centerFrequency"
          value={params.centerFrequency}
          onChange={handleChange}
          step="any"
        />
      </label>
      <label>
        Duration (s):
        <input
          type="number"
          name="duration"
          value={params.duration}
          onChange={handleChange}
          step="any"
          min="0.001"
        />
      </label>
      <label>
        SNR (dB):
        <input
          type="number"
          name="snrDb"
          value={params.snrDb}
          onChange={handleChange}
          step="any"
        />
      </label>
      <button onClick={() => {/* Trigger simulation */}}>Generate Signal</button>
    </div>
  )
}

export default SignalGeneratorControls